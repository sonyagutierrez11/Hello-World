var Workspace = require("../models/workspace");

module.exports = new Workspace();
