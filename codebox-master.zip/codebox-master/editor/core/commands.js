var Commands = require("../collections/commands");

module.exports = new Commands();
