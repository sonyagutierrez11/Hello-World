var User = require("../models/user");

module.exports = new User();
